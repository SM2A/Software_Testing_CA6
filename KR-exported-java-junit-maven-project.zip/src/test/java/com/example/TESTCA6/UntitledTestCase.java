package com.example.TESTCA6;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.io.FileUtils;
import java.io.File;

public class UntitledTestCase {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @Before
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new ChromeDriver();
    baseUrl = "https://www.google.com/";
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("http://localhost:8080/swagger-ui/index.html");
    driver.findElement(By.xpath("//h4[@id='operations-tag-user-controller']/small")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div/div")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div/div[2]/button")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).sendKeys("{\n  \"id\": 123,\n  \"name\": \"Test\",\n  \"userId\": \"123\"\n}");
    driver.findElement(By.xpath("//div[@id='operations-user-controller-addOneUsingPOST_3']/div[2]/div/div[2]/button")).click();
    driver.findElement(By.xpath("//h4[@id='operations-tag-student-controller']/small/div/p")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/div[2]/label/div/select")).click();
    new Select(driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/div[2]/label/div/select"))).selectByVisibleText("application/json");
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div/div[2]/button")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).sendKeys("{\n  \"graduateLevel\": \"Masters\",\n  \"studentId\": 123,\n  \"studentNo\": {\n    \"number\": \"123\"\n  },\n  \"userId\": \"43\"\n}");
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div[2]/button")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).sendKeys("{\n  \"graduateLevel\": \"Masters\",\n  \"studentId\": 123,\n  \"studentNo\": {\n    \"number\": \"123\"\n  },\n  \"userId\": \"123\"\n}");
    driver.findElement(By.xpath("//div[@id='operations-student-controller-addStudentUsingPOST']/div[2]/div/div[2]/button")).click();
    driver.findElement(By.xpath("//h4[@id='operations-tag-enrollment-list-controller']/small")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div/span[2]/a/span")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div/div[2]/button")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/div/label/div/select")).click();
    new Select(driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/div/label/div/select"))).selectByVisibleText("application/json");
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).click();
    //ERROR: Caught exception [ERROR: Unsupported command [doubleClick | xpath=//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea | ]]
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).clear();
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div/div[2]/div/table/tbody/tr/td[2]/div[2]/div/div/textarea")).sendKeys("{\n  \"enrollmentListId\": 123123,\n  \"enrollmentListName\": \"TestList\",\n  \"sections\": [\n    {\n      \"courseCredits\": 0,\n      \"courseId\": 0,\n      \"courseNumber\": {\n        \"courseNumber\": \"string\"\n      },\n      \"courseTitle\": \"string\",\n      \"examTime\": {\n        \"end\": \"2023-01-18T19:39:28.437Z\",\n        \"start\": \"2023-01-18T19:39:28.437Z\"\n      },\n      \"schedule\": [\n        {\n          \"dayOfWeek\": \"string\",\n          \"endTime\": \"string\",\n          \"startTime\": \"string\"\n        }\n      ],\n      \"sectionId\": 0,\n      \"sectionNo\": \"string\"\n    }\n  ],\n  \"student\": {\n    \"graduateLevel\": \"Masters\",\n    \"studentId\": 0,\n    \"studentNo\": {\n      \"number\": \"123\"\n    },\n    \"userId\": \"123\"\n  }\n}");
    driver.findElement(By.xpath("//input[@value='']")).click();
    driver.findElement(By.xpath("//input[@value='123']")).clear();
    driver.findElement(By.xpath("//input[@value='123']")).sendKeys("123");
    driver.findElement(By.xpath("//div[@id='operations-enrollment-list-controller-addOneUsingPOST']/div[2]/div/div[2]/button")).click();
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
